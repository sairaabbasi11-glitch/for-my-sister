# A little book for my sister

A small multi-page website made with HTML, CSS and JavaScript.

Pages: Login (index.html), Home, Quotes, Memories, Gallery, A letter.

To change the sister's name, username and password, edit the top of `script.js`.
